﻿Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        If username = "" Or password = "" Then
            MessageBox.Show("Please enter username and password.")
        ElseIf username = "admin" And password = "1234" Then
            MessageBox.Show("Login successful!")
        Else
            MessageBox.Show("Invalid username or password.")
        End If


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtUsername.Clear()
        txtPassword.Clear()
        txtUsername.Focus()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Application.Exit()

    End Sub
End Class
